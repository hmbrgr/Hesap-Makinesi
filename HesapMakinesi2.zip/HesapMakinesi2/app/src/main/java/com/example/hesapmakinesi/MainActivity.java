package com.example.hesapmakinesi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private TextView cikti;
    private int sonucsayi;
    private String secilenIslem;
    private double virgullusonucsayi;
    private boolean virgulvar = false;
    private int carpimsonucsayi=1;
    private double carpimsonucsayivirgullu=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cikti = findViewById(R.id.textView);
    }

    @SuppressLint("SetTextI18n")
    public void sayiEkle(String sayi) {
        cikti.setText(cikti.getText().toString() + sayi);
    }

    public void temizle(View view) {
        cikti.setText("");
        sonucsayi = 0;
        virgullusonucsayi = 0.0;
        virgulvar = false;
    }

    @SuppressLint("SetTextI18n")
    public void islemSec(String islem) {
        cikti.setText(cikti.getText().toString() + islem);
        secilenIslem=islem;
    }

    public void sonuc(View view) {
        sonucsayi = 0;
        virgullusonucsayi = 0.0;
        if(secilenIslem.equals("%")){
            virgulvar=true;
            String[] sayilar = cikti.getText().toString().split("\\%");
            for (String sayi : sayilar) {
                virgullusonucsayi = (Double.parseDouble(sayi))/100;
            }
            cikti.setText(String.valueOf(virgullusonucsayi));
        }
        if(virgulvar){
            if(secilenIslem.equals("+")){
                String[] sayilar = cikti.getText().toString().split("\\+");
                for (String sayi : sayilar) {
                    virgullusonucsayi += Double.parseDouble(sayi);
                }
                cikti.setText(String.valueOf(virgullusonucsayi));
            }
            else if(secilenIslem.equals("*")){

                String[] sayilar = cikti.getText().toString().split("\\*");
                for (String sayi : sayilar) {
                    carpimsonucsayivirgullu *= Double.parseDouble(sayi);
                }
                cikti.setText(String.valueOf(carpimsonucsayivirgullu));
            }
            else if(secilenIslem.equals("/")){
                String[] sayilar = cikti.getText().toString().split("\\/");
                for (String sayi : sayilar) {
                    virgullusonucsayi /= Double.parseDouble(sayi);
                }
                cikti.setText(String.valueOf(virgullusonucsayi));
            }
            else if(secilenIslem.equals("-")){
                String[] sayilar = cikti.getText().toString().split("\\-");
                for (String sayi : sayilar) {
                    virgullusonucsayi -= Double.parseDouble(sayi);
                }
                cikti.setText(String.valueOf(virgullusonucsayi));
            }

        }
        if(!virgulvar){
            if(secilenIslem.equals("+")){
                String[] sayilar = cikti.getText().toString().split("\\+");
                for (String sayi : sayilar) {
                    sonucsayi += Integer.parseInt(sayi);
                }
                cikti.setText(String.valueOf(sonucsayi));
            }
            else if(secilenIslem.equals("*")){
                String[] sayilar = cikti.getText().toString().split("\\*");
                for (String sayi : sayilar) {
                    carpimsonucsayi *= Integer.parseInt(sayi);
                }
                cikti.setText(String.valueOf(carpimsonucsayi));
            }
            else if(secilenIslem.equals("/")){
                String[] sayilar = cikti.getText().toString().split("\\/");
                for (String sayi : sayilar) {
                    sonucsayi /= Integer.parseInt(sayi);
                }
                cikti.setText(String.valueOf(sonucsayi));
            }
            else if(secilenIslem.equals("-")){
                String[] sayilar = cikti.getText().toString().split("\\-");
                int sonucsayi = Integer.parseInt(sayilar[0]);
                for (int i = 1; i < sayilar.length; i++) {
                    sonucsayi -= Integer.parseInt(sayilar[i]);
                }
                cikti.setText(String.valueOf(sonucsayi));
            }

        }
    }

    public void bir(View view) {
        sayiEkle("1");
    }

    public void iki(View view) {
        sayiEkle("2");
    }

    public void uc(View view) {
        sayiEkle("3");
    }

    public void dort(View view) {
        sayiEkle("4");
    }

    public void bes(View view) {
        sayiEkle("5");
    }

    public void alti(View view) {
        sayiEkle("6");
    }

    public void yedi(View view) {
        sayiEkle("7");
    }

    public void sekiz(View view) {
        sayiEkle("8");
    }

    public void dokuz(View view) {
        sayiEkle("9");
    }

    public void sifir(View view) {
        sayiEkle("0");
    }

    public void topla(View view) {
        islemSec("+");
    }
    public void carp(View view) {
        islemSec("*");
    }
    public void cikar(View view) {
        islemSec("-");
    }
    public void bol(View view) {
        islemSec("/");
    }
    public void virgul(View view){
        sayiEkle(".");
        virgulvar = true;
    }
    public void yuzde(View view){
       islemSec("%");
    }
}
